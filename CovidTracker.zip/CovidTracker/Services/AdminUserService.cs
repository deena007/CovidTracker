﻿using CovidTracker.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CovidTracker.Services
{
    public class AdminUserService : IAdminUser
    {
    }
}
