﻿using CovidTracker.Interface;
using CovidTracker.ModelData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CovidTracker.Services
{
    public class MemeberUserService : IMemberUser
    {
        public static List<User> members;

        public MemeberUserService()
        {
            members = new List<User>();
        }
        public User registerUser(User user)
        {
            User newUser = new User();
            if(User.userValidation(user))
            {
                newUser = new User(user);
                members.Add(newUser);
            }
            return newUser;
        }

        public SelfAssessmentResponse selfAssessment(SelfAssessmentRequest request)
        {
            SelfAssessmentResponse response = new SelfAssessmentResponse();
            int risk = -1;
            //if (members.Where(r => r.userId == request.userId).ToList()?.Any() == true)
            if (true)
            {
                if (request.symptoms?.Any() == false && request.contactWithCovidPatient == false && request.travelHostory == false)
                {
                    risk = 5;
                }
                else if ((request.symptoms?.Any() == true && request.symptoms.Count == 1) && (request.contactWithCovidPatient == true || request.travelHostory == true))
                {
                    risk = 50;
                }
                else if ((request.symptoms?.Any() == true && request.symptoms.Count == 2) && (request.contactWithCovidPatient == true || request.travelHostory == true))
                {
                    risk = 75;
                }
                else if ((request.symptoms?.Any() == true && request.symptoms.Count > 2) && (request.contactWithCovidPatient == true || request.travelHostory == true))
                {
                    risk = 95;
                }
            }
            response.riskPercentage = risk;
            return response;
        }
    }
}
