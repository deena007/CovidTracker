﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CovidTracker.ModelData
{
    public class User
    {
        private static int counter = 1;
        public int userId { get; set; }
        public string name { get; set; }
        public string phoneNumber { get; set; }
        public string pinCode { get; set; }

        public User()
        {

        }

        public User(User user)
        {
            userId = getId();
            name = user.name;
            phoneNumber = user.phoneNumber;
            pinCode = user.pinCode;
        }

        public static bool userValidation(User user)
        {
            if (string.IsNullOrWhiteSpace(user.name))
                return false;
            if (string.IsNullOrWhiteSpace(user.phoneNumber))
                return false;
            if (user.phoneNumber.Length < 10)
                return false;
            if (!user.phoneNumber.All(char.IsDigit))
                return false;
            if (string.IsNullOrWhiteSpace(user.pinCode))
                return false;
            if (user.pinCode.Length < 6)
                return false;
            if (!user.pinCode.All(char.IsDigit))
                return false;

            return true;
        }

        private static int getId()
        {
            return counter++;
        }
    }
}
