﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CovidTracker.ModelData
{
    public class SelfAssessmentRequest
    {
        public int userId { get; set; }
        public List<string> symptoms { get; set; }
        public bool travelHostory { get; set; }
        public bool contactWithCovidPatient { get; set; }
    }


}
