﻿using CovidTracker.Interface;
using CovidTracker.ModelData;
using CovidTracker.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CovidTracker.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        //private IMemberUser _user;
        //public UserController()
        //{
        //    IMemberUser _user = new MemeberUserService();
        //}


        // POST api/<UserController>
        [HttpPost]
        [Route("registerUser")]
        public IActionResult registerUser([FromBody] User user)
        {
            IMemberUser _user = new MemeberUserService();
            var newUser = _user.registerUser(user);
            if (newUser.userId == 0)
                return BadRequest();
            return Ok(newUser.userId);
        }

        // POST api/<UserController>
        [HttpPost]
        [Route("selfAssessment")]
        public IActionResult selfAssessment([FromBody] SelfAssessmentRequest req)
        {
            IMemberUser _user = new MemeberUserService();
            var res = _user.selfAssessment(req);
            if (res.riskPercentage == -1)
                return Unauthorized();
            return Ok(res);
        }
    }
}
