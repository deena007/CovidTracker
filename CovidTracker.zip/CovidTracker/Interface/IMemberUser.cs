﻿using CovidTracker.ModelData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CovidTracker.Interface
{
    public interface IMemberUser
    {
        User registerUser(User user);
        SelfAssessmentResponse selfAssessment(SelfAssessmentRequest request);
    }
}
